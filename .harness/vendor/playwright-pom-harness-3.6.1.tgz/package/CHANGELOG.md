# Changelog

## 3.6.1 — Clear execution and automation reports

### Upgrade actions

- Re-run setup from the 3.6.1 archive in each project, then reload Claude Code skills or restart Codex to discover the updated execution and automation guidance. Existing customized code and configuration remain subject to review.
- Regenerate reports through `/execute-test` or `/automate-test` to use the shared HTML experience. Share the report bundle when the skill finishes and attach it to the related PR, preserving its companion files and relative links. Existing saved HTML files are not rewritten; no GitHub Actions report upload is required.

### Changes

- Add a shared offline HTML report for execution and automation results, with a pie chart, compact collapsible case groups, pagination, search, sorting and multiple status selection. Show failed and blocked cases with clear reasons and next actions.
- Match Summary and Defects navigation across both skills and place an accessible sun/moon theme control in the upper-right header. Remove the Result data control and technical report clutter such as raw JSON, internal identifiers, hashes and provenance inventories; retain expected and actual results, useful evidence and authoritative internal records.
- Retire the duplicate Core report pages and links. Update both skills to share the final report with the user and attach its bundle to the related PR. Keep existing Allure, Playwright and GitHub Actions reporting unchanged.
- Add installed-browser report checks for filtering, pagination, navigation, themes, accessibility and privacy on Windows and Linux.

## 3.6.0 — MySQL execution and URL-encoded API forms

### Upgrade actions

- Re-run setup from the 3.6.0 archive in each project, then reload Claude Code skills or restart Codex to discover the updated guidance. Existing customized code and configuration remain subject to review. Existing JSON API definitions and SQL Server/PostgreSQL targets need no migration.
- For MySQL execution, configure an explicit `engine: "mysql"` target and operation definitions, use MySQL 8.4 with a dedicated scoped principal, and follow [the database guide](docs/reference/databases.md). Schema must match the database; verified TLS requires a DNS server name. Guarded restoration and generated MySQL POM services remain unsupported.
- For URL-encoded API requests, use `form` instead of `json`, bind sensitive fields through protected inputs, and follow [the API guide](docs/reference/api.md). Forms accept scalar fields only; JSON and form bodies are mutually exclusive.

### Changes

- Add native MySQL execution through the pinned `mysql2` driver, including typed parameter bindings, scoped privilege checks, read-only SELECT transactions, bounded cancellation, protected outputs and identity-bound cleanup. Preserve uncertain mutation effects when a COMMIT reply is lost; refuse unsupported SQL and guarded restoration.
- Add installed-archive MySQL proofs on Linux for CRUD, native types, privilege rejection, lock waits, COMMIT uncertainty, cleanup and a mixed browser/API/database scenario. Record dependency licenses and provenance.
- Support `application/x-www-form-urlencoded` API bodies in standalone, sequential and manual execution. Validate field types and Content-Type before dispatch, enforce the request limit after encoding, and screen known form-encoded secrets from evidence. Existing timeout, cancellation and mutation recovery contracts remain in force.
- Update and pin runtime dependencies to `@azure/identity` 4.14.0, `open` 11.0.4 and `wsl-utils` 1.0.1. Refresh the dependency lock and license inventory. Use nested installation to preserve independent consumer dependencies, and validate setup and `npm ci` with an older identity dependency.

## 3.5.0 — Test maintenance and blocked-case recovery

### Upgrade actions

- Re-run setup from the 3.5.0 archive in each project, then reload Claude Code skills or restart Codex to discover `/maintain-test` and the updated workflow guidance. Existing customized code and configuration remain subject to review.
- Use `/maintain-test` to reassess failed, flaky, changed or blocked cases. Preserve existing evidence and repair counts. For an accepted requirement revision, follow `generate revise` in [the maintenance guide](docs/maintenance.md); repaired automation requires fresh independent review and two independent scoped green runs.

### Changes

- Add a maintenance skill that classifies failures with evidence, compares source revisions and affected callers, verifies every unblock condition, and resumes the appropriate execution or automation stage. Cover cases without generated specs, partial recovery, unclear requirements and exhausted repair budgets.
- Add atomic `generate revise` registration for accepted requirement changes and evidence-backed `application-change` candidates for external fixes. Retain source identity, failure history, prior candidates and the cumulative three-round repair budget.
- Integrate maintenance with the existing execution, generation, framework-review and plan-tracker workflows. Unresolved blockers remain recorded; restoring a prerequisite alone never marks a case done.

## 3.4.0 — Reliable releases and page guidance

### Upgrade actions

- Re-run setup from the 3.4.0 archive in each project, then reload Claude Code skills or restart Codex so the updated guidance is discovered. Existing customized code and configuration remain subject to review.
- Review directly routable page classes for a public async `navigate()` action and move direct `page.goto()` calls into the owning action. Preserve link/menu/redirect journeys and authentication prerequisites; document shared or flow-only exceptions. New navigation checks are advisory unless `--fail-on-warn` is enabled.
- When targeting a specific list record, use observed suitable search where available and verify the exact row identity before acting. Preserve scenarios that intentionally test browsing, pagination or ordering; do not infer search support from a generic input.

### Changes

- Separate ordinary CI validation from on-demand release builds. A manually prepared
  version PR and dispatched release workflow validate one archive across every
  platform and create a draft GitHub release; publication remains manual.
- Stop stale release candidates when workflow files differ from the current default
  branch, with a fresh-run instruction. Create the draft before its tag so a rejected
  draft request cannot leave an orphan version tag; preserve matching upload retries.
- Retain sanitized failure stages and source coordinates for the native parallel
  CI proof, including startup failures whose cleanup also fails.
- Use the Google Docker Hub cache for Linux CI fixtures with unchanged image
  digests to avoid anonymous image pull limits.

- Validate declared skill links against the current installed package and report invalid link manifests through controlled readiness errors. Preserve legacy adoption omissions and readiness exit behavior.
- Require page-owned navigation for supported direct routes, with explicit parameters, configured URL ownership and documented shared/flow-only exceptions. Add advisory navigation checks and align generation and review guidance.
- Prefer observed suitable search when targeting specific list records, with search-scope checks, exact-row identity and scenario-intent exceptions.
- Clarify README navigation, workflow phases, focused source lookup and reviewed knowledge reuse; document optional project-level Graphify evaluation.
- Stabilize Windows lifecycle and shared cleanup deadline tests, retain assertion failure diagnostics, and install the example browser before fresh package checks.

## 3.3.0 — Execution test folder

### Upgrade actions

- Before continuing an existing ADO workflow, manually move its `ado-suite-*` and `ado-story-*` folders from `test/` into `execution-tests/`, preserving all contents. Reconcile any existing destination before moving. Setup does not move these folders; publishing, tracker, metrics and convention checks use only the new location. See [manual migration](docs/azure-devops.md#fetch-storage-and-migration).

### Changes

- Rename the default parent folder for fetched Markdown cases and supporting manifests, traceability and verification state to `execution-tests/`. Update its readers, ignore rules, package inventory and guidance together; preserve explicit fetch `--out`, filenames, source fingerprints and refinements.

## 3.2.3 — Allure locator titles

### Upgrade actions

- Existing consumers: merge the updated `examples/src/utils/AllureReport.ts` into your utility. Replace the separate `allure-playwright` and generator entries with one `./src/utils/AllureReport.ts` entry before the HTML reporter, preserving the official reporter's options. Apply the count-comparison title change in `Expects.ts`. Setup preserves existing customized code and config.

### Changes

- Restore inline locator text for native actions and assertions using public Playwright step metadata inside `AllureReport.ts`. It handles normal capture and HTML generation; scoped reporting reuses the consumer's maintained class for capture only. Count comparisons explicitly include both locators; dependency versions and assertion behavior stay unchanged.

## 3.2.2 — Simpler generated consumer projects

### Upgrade actions

- Run setup from the 3.2.2 archive in each project, then reload the agent's skills. Setup replaces managed `automate-suite` links with `automate-test`; customized skills and consumer code remain subject to review.
- Review existing specs against the updated lifecycle and reporting guidance. Remove unnecessary tracing-only wrappers and parameters, retain safe domain cleanup, and preserve justified fixtures, application contracts and reporter customizations. Setup does not refactor consumer code automatically.
- When continuing an eligible legacy generation source, register its explicit one-time `migration: 'case-assertions'` transition through the existing candidate command. Preserve history and the repair count; obtain fresh independent review and two fresh scoped v2 green runs. Unrelated repairs still consume a round. See [migration instructions](docs/PIPELINE.md#legacy-candidate-migration).
- Correct newly reported paired-JSON and business test-data dependency violations. Review warnings about imports, metadata and link templates; warnings alone do not block ordinary consumer CI. Observe the documented reporting redaction limits and artifact access/retention requirements.

### Changes

- Rename `automate-suite` to `automate-test`, with explicit story, suite and local invocation examples. The observed execution, POM generation, independent review and two-green workflow is unchanged.
- Re-run setup to replace managed old-name links. Recognized legacy prerequisite knowledge migrates to `.harness/knowledge/prerequisites.md`; customized folders and foreign links are preserved for review. No old-name alias is installed.
- `docs/RELEASING.md`: running the consumer flows locally is optional when the release pull request's `Harness validation` run passes, because CI runs them on Windows and Linux with npm 11 and npm 12.
- Add fail-level convention rules `spec-data-source` (literal spec JSON imports/reads must use the paired JSON) and `business-test-data-dependency` (business classes must not load test data or import spec code). Shipped CI templates run these as blocking checks; consumers must correct newly reported dependencies before merging. Semantic schema ownership remains an independent-review check.
- Clarify spec-local data typing, operation-sized method parameters and disposable credential ownership. Infer spec data shapes from their paired JSON without introducing named schema interfaces; use optional attempted identities retained before creation and ownership-checked domain cleanup from ordinary teardown.
- Native execution accepts explicit generated and approved synthetic protected inputs alongside externally provisioned env inputs. Credentials remain reference-only in frozen operations; report protection has documented channel limits; disposable passwords need no per-case env keys.

- Default generated GUI specs to standard Playwright imports and the built-in isolated page; preserve justified public fixtures. Remove callback cleanup registration, private telemetry, replacement test wrappers and source-key business plumbing from generation guidance.
- Keep timestamp-based case data and paired-JSON synthetic passwords as the simple defaults. Preserve existing context, deletion and authentication contracts; the starter reports its missing ownership/absence checks instead of assuming a credential-based lookup API.
- Replace marker-level runtime proof with v2 case-level assertion receipts and step/expectation review mappings. Scope, integrity, independent review and two-run gates remain; runtime receipts no longer claim every source expectation executed.
- Upgrade existing generation explicitly with `migration: 'case-assertions'` on the existing candidate command. One legacy transition preserves history, identities and the repair count even at round three; require fresh review and two v2 runs. Unrelated repairs still consume a round. See [migration instructions](docs/PIPELINE.md#legacy-candidate-migration); custom consumer code is not rewritten.
- Await asynchronous Allure metadata with literal real IDs and transport validated literal reporter links into scoped capture. Preserve custom configuration; dynamic templates produce an unresolved diagnostic and raw scoped IDs without changing verdicts. Remove active starter placeholder URLs.
- Fail confirmed private Playwright instrumentation/deep imports without suppression or baseline escape. Warn on nonstandard test imports, source markers, metadata misuse and absent/placeholder/unresolved links; warnings alone do not block ordinary consumer CI. Reviewed public fixtures retain existing warning suppression.
- Document selected-header/structured-key redaction limits and title-only secret protection. Native artifacts still need restricted access and retention; no private telemetry layer is added.

## 3.2.1 — Clearer final execution reports

### Upgrade actions

- Re-run setup from the 3.2.1 archive in each project to use the redesigned final execution report for future executions.
- New report folders use one `execute-` prefix. Existing report folders and their links remain usable.

### Changes

- Add a compact case-level dashboard, outcome chart, attention list, and searchable, filterable, sortable test results.
- Present expected and actual results, verification methods, retry history, cleanup and diagnostics as readable evidence, with full raw records available on demand.
- Keep case outcomes separate from historical attempts, verification classifications, diagnostic occurrences and defect groups; preserve execution and verdict semantics.
- Add responsive layouts and screenshot previews, with offline and no-JavaScript support and a hash-authorized inline script. No new runtime dependencies.

## 3.2.0 — M19 manual execution

Execute captured ADO manual cases interactively through the native browser, API and DB runtimes, with condition-bound verdicts, verified reports and recoverable ADO delivery.

### Upgrade actions

- Re-run setup from the 3.2.0 archive in each project.
- Upgrade teammates before adding browser startUrl/users or ado.bugs configuration keys; earlier validators reject them.
- For optional bug/result delivery, configure a PAT with Work Items and Test Management read/write scopes. Previews remain the default.

### Changes

- Accept plain and frame-prefixed native browser references, including quoted snapshot keys; retain snapshot membership and state-version checks.
- Settle browser attempts atomically across completion, interruption and deadlines; retain earlier failures and incomplete cleanup obligations.
- Verify rendered DOM reads with explicit frame coverage and compact, rechecked assertion provenance. Legacy browser evidence remains readable with restricted delivery eligibility.
- Recover bounded command receipts, owned sessions and ADO delivery without replaying uncertain mutations; default Bug candidates to reliable matching failures.
- Support 500 ten-step scenarios within bounded aggregate documents, scoped readiness and host-bound command guards.
- Add the execute-test skill and execute CLI, captured revisions/iterations, a sequential live host, cleanup receipts, login reuse, diagnostics and dashboard/defect reporting.
- Reassess evidence before delivery, retain historical valid FAILs and let explicit valid reruns replace integrity-invalid runs while preserving audit history.
- Flush create identities in ADO acknowledgements and recover filings/publications through stable tags/names. No new runtime dependencies.
- Enforce exact subject identity, visual evidence, end-step artifact integrity and bounded provenance; reserve cleanup time across browser/API/DB work. Normalize ADO classification paths, filter point maps after omissions, retain revision flags and stabilize parameterized diagnostic fingerprints.

## 3.1.2 — Upgrade actions only on update

A first setup now ends with its readiness and next steps, without upgrade actions that
do not apply.

### Upgrade actions

- Run setup from the 3.1.2 archive in each project: `npx --yes --package "<full path to playwright-pom-harness-3.1.2.tgz>" pom-harness setup`.

### Changes

- A first setup no longer lists upgrade actions; they appear only when updating from an earlier installed version. Previously a fresh install, a repair run and a configuration run listed every version's actions under "since your previous setup".

## 3.1.1 — Retire .agentex and pin @azure/msal-browser

Fresh installs get the cleared dependency graph again, and the package and setup no
longer use the legacy `.agentex/` directory.

### Upgrade actions

- Run setup from the 3.1.1 archive in each project: `npx --yes --package "<full path to playwright-pom-harness-3.1.1.tgz>" pom-harness setup`.
- Delete the `.agentex/cache/` line that 3.1.0 setup added to `.gitignore`; nothing uses it.

### Changes

- Ship the page-map template and contract with the `automate-suite` skill, as `assets/page-map-template.md` and `references/page-map.md`; the contract now requires review before facts are promoted. The package no longer ships `.agentex/`, and setup no longer migrates `.agentex/page-map/` or adds the unused `.agentex/cache/` ignore line.
- Pin `@azure/msal-browser` 5.23.0 as an exact runtime dependency, as `@js-joda/core` and `tedious` are. `@azure/identity` accepts `^5.5.0`, so plain installs re-resolved it to 5.24.0 once that was published, and setup reported a drifted dependency closure.

## 3.1.0 — M18 archive adoption

A project now adopts the harness from its versioned release archive in one command,
and updates the same way. Teammates and CI get it from `npm ci`.

### Upgrade actions

- Run setup from the 3.1.0 archive in each project: `npx --yes --package "<full path to playwright-pom-harness-3.1.0.tgz>" pom-harness setup`. It replaces the sibling-checkout links and recognized legacy `.claude/skills` copies, and lists anything that needs a decision.
- Stop launching Claude with `--plugin-dir ../playwright-pom-harness`; the project's linked skills replace it.
- Repoint old hook commands and `package.json` shortcuts that run `../playwright-pom-harness/scripts/...` to `npx --no pom-harness <command>`; the hook template is now `node_modules/playwright-pom-harness/scripts/hooks/claude-hooks.example.json`.
- Re-verify generated suites: the runtime library and its dependency graph changed.

### Adoption

- Add the `pom-harness` command (`scripts/cli.mjs`).
  - `setup` installs the release archive as an exact development dependency committed under `.harness/vendor/`, or updates, repairs and configures the installed harness.
  - `setup --restore` undoes the last run. `check` reports per-feature readiness and can add empty `.env` keys. `unlink` detaches the links before a rollback. The workflow scripts run as pass-through commands.
  - Every command acts only as the project's own installation, at the version its lockfile records.
- Link each skill into `.claude/skills/` and `.agents/skills/`, with `ROOTS.md` pointers. Links are junctions on Windows and relative symbolic links elsewhere.
  - The committed `.harness/links.json` records them, and a guarded `postinstall` restores them after `npm ci`. Per-link ignore lines keep them out of git.
  - Setup creates links only where nothing exists and repairs only content-free harness links. Anything else stops the run before any write, with every conflict listed.
- Preflight the new version's complete adoption plan before installing. Journal every write, removed folder and replaced link target, so `setup --restore` returns the project to its pre-setup bytes; it runs `npm ci` only when a lockfile existed before.
- Migrate legacy `.claude/skills` folders by digest, including the 3.0.x redirects. A folder whose tracked data would move into the git-ignored `.harness/state/` is kept and reported.
- Compare managed instruction blocks after newline normalization, so CRLF clones update cleanly. A released block is replaced; an edited block still stops setup. The new block points to the `harness-setup` skill.
- Add the branch rule to the managed instruction block that setup merges into a project's `CLAUDE.md` and `AGENTS.md`: never commit or push directly to the default branch; reuse the ongoing feature branch, or create `automation/<source-id>-<slug>`, `harness/<topic>`, `feature/<topic>` or `fix/<topic>`; deliver through a pull request, committing, pushing or opening one only with the user's authorization. Setup replaces the released 3.0.x and 3.1.0 blocks in place; an edited block still stops setup for review. The pipeline guide's prerequisites point to the rule.
- Make the environment profile optional; add one with `setup --environment <name> --mode <mode>`.
- Add a minimal starter for projects without Playwright: configuration and utilities, with exact dependencies installed alongside the harness, and no demo pages or tests. `src/config/targets.ts` reads destinations from `.harness/targets.json`, so they are entered once.
- Add the `harness-setup` skill. It covers install, update, configuration (the mode question, targets, Azure DevOps, empty secret keys, CI pipelines), teammates and rollback.

### Runtime and package

- Ship the pinned native CLI (`@playwright/cli` 0.1.22 with its Playwright build) as a runtime dependency, resolved from the package location instead of the nested spike install. Pin `@js-joda/core` 6.1.0 and `tedious` 20.0.0, which npm re-resolved on plain installs. Add their provenance records. The spike stays development-only.
- Stop shipping `.claude/` (redirect skills and the permissive settings template) and `CLAUDE.md`. Hooks move to `scripts/hooks/claude-hooks.example.json`, without a permissions block.
- `check-conventions` checks the current folder by default. The API and database runtimes read default credentials from the project's `.env` without changing `process.env`; the shell wins.
- Pin the examples' Playwright, Allure and CLI versions exactly, and add the TypeScript settings that generation needs.
- Skills and guides run commands as `npx --no pom-harness <command>` and no longer hard-code the skill count. The pipeline templates check conventions.

### Automation pipeline guide

- Add `docs/PIPELINE.md`, one guide to the automation pipeline in execution order: ten named phases with their inputs, outputs, commands and gates, the repair loop, consumer state paths and a mapping from the legacy ADO phase names. It summarizes and links the M3–M16 contracts, which remain authoritative. The README gains a short "How automation works" section pointing to it.

### Windows owned-process trees

- Record a process as an owned descendant only when it was created no earlier than its parent. Windows keeps an exited parent's PID on its children and reuses PIDs, so browser cleanup could adopt older, unrelated processes and terminate them; this explains the intermittent Windows native browser gate failures, including a supervisor exit 1 with no summary. Creation identities compare exactly as integers, and a process without a readable identity is never adopted. A regression test covers the reused-PID case.
- Apply the same rule to the development-only M4 CLI spike's own tree helpers. Its Windows probe re-run passes 13/13 checks; Linux was not re-run.

### Consumer seeding guidance

- Document seeding a fresh consumer from `examples`. Superseded within this release: setup adds the starter, and harness commands run as `npx --no pom-harness <command>`, so no copied shortcuts need repointing.

### Installed validation repair

- Constrain the fresh CI consumer to the existing cleared dependency versions when npm relocates the shrinkwrap; retain exact provenance checks without changing dependencies or notices.
- Parse npm JSON from stdout while preserving combined, hashed diagnostics; add three CI regression tests.
- Correct the bundled example's `fetch:story` shortcut to resolve the parent package script; document its explicit external consumer and adoption path requirements.
- Correct the remaining five bundled harness shortcuts; exercise all six through actual npm invocations from the package root and example directory in the adoption tests.

### ADO story retrieval

- Add read-only `fetch-ado-story.mjs --story <id>`: retrieve the test cases linked to a user story without plan or suite IDs. Tested By links by default; `--links tested-by,child,related` selects others per run.
- Bind link targets to the configured collection, take test-case types from the project's test-case category, and report non-test or other-project items by ID without reading their content.
- Reuse the suite case reader and bounds; write the suite contract under `test/ado-story-<id>/` and an `ado-story-<id>` neutral source. Suite fetch output is pinned unchanged; exclusions are recorded but not fingerprinted.
- Include `ado-story-<id>` folders in convention, metrics and tracker scans. A case held by several folders counts once in metrics totals, from its newest verification; recorded results that disagree count it as no-state, and tracker sync skips it with a warning, in deterministic folder order. Library changes refresh consumers' M13 runtime fingerprints; re-verify after upgrading.
- No story-scoped publication or automation marking, automate-suite skill route or live-tenant validation.

### Final-review corrections

- Guarantee owned-browser cleanup after interrupted bodies or failed result recording, preserving frozen phases, assertion failures and the shared cleanup deadline.
- Accept genuinely empty ADO metadata consistently through retrieval, conversion and legacy rendering; retain refinement for nonempty or malformed metadata.
- Add identifying context and assessed-status wording to the four API/database reference-fixture business steps; verify actual Allure nesting and attachment associations.
- Extend the installed browser gate to 38 exact native checks. Preserve public interfaces, dependency versions and normal execution policy.

## 3.0.17 — M17 CI and installed-package validation

- Validate actual npm archives in fresh Windows/Linux installations, with pinned dependency provenance and package immutability checks.
- Publish the existing dependency lock as `npm-shrinkwrap.json`; exclude nested installed dependencies when repacking and use the distributed lock for generation fingerprints.
- Add a fixed CI checklist that rejects missing, skipped and zero-scope checks, plus real native browser and Linux API/database/parallel proofs.
- Allow the existing host and full-workflow acceptance probes to use a separate consumer with the actual installed package.
- Drain cancellation and recover exact owned native resources after a proof timeout, with protected atomic ownership receipts and real fault evaluations.
- Resolve Windows consumer paths for native allowlists, retain private compiler diagnostics, and support the explicit local Docker Desktop fixture route.
- Supply the generated-test fixture's Chrome prerequisite in the Linux client and recognize exact literal native consumer-directory prefixes without accepting shell additions.
- Keep authenticated host evidence separate from public CI artifacts and retain explicit readiness gates. No runtime dependency upgrade, execution-policy change or release authorization.

## 3.0.16 — M16 bounded parallel execution

- Add opt-in batches of independent complete sequential lifecycles, with concurrency 1 by default and an explicit maximum of 8.
- Reject shared-data conflicts before execution; isolate run storage and assessed results, retain queued cancellation/deadline outcomes and drain required cleanup.
- Keep one active batch per consumer, immutable queued inputs and guarded runtime exploration. Preserve uncertain effects and incomplete execution without inventing verdicts.
- Prove real session isolation, API lifecycle behavior and both database drivers against sequential semantic outcomes. No new dependency, browser language, general scheduler or generated-test worker change.

## 3.0.15 — M15 sequential workflow parity

- Connect native Claude/Codex source refinement, observed execution, unreviewed knowledge candidates, actual POM authorship, independent review, two scoped green processes and Allure 3 reporting in a fixed acceptance proof.
- Compare semantic outcomes and binding relationships while revalidating each run's original evidence, generated execution records and reports.
- Include normal mutation autonomy, required cleanup/restoration and intentional persistence; retain controlled negative outcomes and sequential execution.
- No new execution engine, browser command language, dependency or automatic external delivery.

## 3.0.14 — M14 reporting and Allure integration

- Reporting follow-up: replace the Java generator with pinned Allure Report 3.19.1; retain test/action APIs, report locations, native status and harness verdict authority.
- Use explicit local single-file configuration and post-flush example generation; preserve nested attachments and block outbound report analytics.
- Render validated execution results as JSON, Markdown and self-contained static HTML, preserving verdicts, attempts, effects and lifecycle intent.
- Attach sanitized execution views inside native technical steps; isolate native Allure captures per verification invocation.
- Generate Allure after reporter flush with integrity checks and a visible recorded verification outcome above native detail.
- Keep reporting failures separate from test verdicts and two-green readiness; preserve sequential execution.
- Add report contract checks and extend the reviewed live consumer proof. No new root dependency or release authorization.

## 3.0.13 — M13 generation, review and verification

- Bind neutral source intent to reassessed execution, durable POM files and independent review.
- Enforce three cumulative repair rounds and two independent exact-scope native green runs, with executed source assertions and intact receipts.
- Reuse shared deterministic API/DB libraries across catalog, helper and inline definitions; keep sequential execution and intent-driven lifecycle policy.
- Add a separate consumer proof and native runner failure fixtures. Local case metadata no longer requires an invented ADO link.
- Refresh the canonical automation route without adding AgenTeX, a browser DSL or a workflow engine.


Package versions belong to this package, not to adopting applications. Historical
private incidents and delivery identifiers are intentionally not retained here.

## 3.0.12 — Unreleased

- M12: separate optional ADO test retrieval, outcome/work-item management and
  source-control delivery behind concrete adapters with shared bounded transport.
- Keep all five compatibility entrypoints consumer-rooted, make external mutations
  explicitly executable, and retain flushed receipts without credentials/payloads.
- Preserve local-only operation, validate publication scope and source identity,
  guard work-item revisions, and verify writes without automatic replay.
- Remove private field/branch defaults and silent missing-case/result handling;
  document compatibility changes and the limits of synthetic contract validation.

## 3.0.11 — Unreleased

- M11: compare validated execution semantics across native Claude and Codex runs,
  preserving business values, producer bindings, recovery and lifecycle decisions.
- Add thin native hook payload translation and fixed browser/API/database host
  proofs with native command receipts, immutable package checks and owned cleanup.
- Verify 19 native Windows execution cases through Claude and Codex, including
  mixed lifecycle behavior and structured Codex denial across the Windows shell.
- Keep host permissions separate from harness capabilities. Full workflow parity
  and parallel execution remain deferred.

## 3.0.10 — Unreleased

- M10: add PostgreSQL through the shared database runtime, using native positional
  binding, scoped privileges, read-only reads and precise native result conversion.
- Preserve catalog/helper/inline/exploration peers, conditional restoration and
  persistent outcomes; keep SQL syntax and version tokens inside concrete drivers.
- Add real PostgreSQL safety/failure probes and semantic comparison of 12 shared
  SQL Server/PostgreSQL scenarios on Windows and Linux clients.
- Pin pg and its dependency graph and record the separate upstream notices.

## 3.0.9 — Unreleased

- M9: share sequential scenario identities, bindings, effects and required lifecycle
  records across the existing browser, API and SQL Server runtimes.
- Add fixed setup/exercise/verify/cleanup callbacks, cross-runtime concurrency refusal,
  shared cleanup deadlines and protected-value screening, and explicit unreached results.
- Prove real mixed scenarios, partial setup, reconciliation, conditional restoration,
  cleanup failures and intentional retention without new dependencies or a workflow DSL.

## 3.0.8 — Unreleased

- M8: add sequential SQL Server execution with actual typed driver bindings,
  lightweight statement classification and dedicated database/schema principals.
- Support dynamic SELECT/INSERT/UPDATE/DELETE, peer catalog/helper/inline sources,
  bounded results, effect accounting, sanitized evidence and safe read recovery.
- Keep lifecycle obligations optional; require conditional identity/version checks
  for restoration, and preserve intentionally persistent outcomes.
- Pin node-mssql and its dependencies, record third-party provenance, and add
  disposable real SQL Server validation for Windows and Linux clients.

## 3.0.7 — Unreleased

- M7: add one deterministic API runtime for catalog, helper, inline and dynamic
  exploratory operations under the same frozen environment capabilities.
- Support bound JSON requests, typed extraction, reliable checks, bounded native
  HTTP(S), credential refresh, effect-aware recovery and sanitized evidence.
- Record optional fixture cleanup, conditional restoration and intentional retention;
  validate CRUD, transport failures and policy controls with local HTTP fixtures.
- Align the root lockfile's package version with the manifest; dependency graph unchanged.

## 3.0.6 — Unreleased

- M6: integrate owned sequential browser sessions with the proven native Playwright
  CLI, shared result validation, finite recovery and intent-driven resource lifecycle.
- Add optional browser target/capability configuration and protected evidence promotion.
- Preserve native commands, failure history and scoped process cleanup; add live
  browser acceptance fixtures without API/DB executors or parallel scheduling.

## 3.0.5 — Unreleased

- M5 only: add deterministic execution records and validators for frozen run inputs,
  environment capabilities, operation provenance and typed value bindings.
- Track invocation/attempt identities, phases, effect certainty, finite recovery,
  affected-row expectations and optional lifecycle obligations according to intent.
- Validate required observations, artifact ownership/integrity and complete results;
  preserve assertion failures and allow safely recovered passes with full history.
- Keep catalogs, helpers and inline definitions as peers, and allow permitted
  uncataloged exploration. No executor, SQL parser, browser command language or
  generic workflow engine is introduced.

## 3.0.4 — Unreleased

- M4 only: pin the official Playwright CLI and resolved dependencies in a separate
  development spike, with fixed synthetic Windows/Linux browser probes.
- Assess native session isolation, current snapshot references, authentication state,
  evidence, error/timeout/crash handling and scoped resource cleanup. Preserve failed
  attempts and require both platforms before a viable gate can pass.
- Record the required noninteractive invocation profile and version-specific output
  behavior without creating a second browser command language or a harness executor.
- Extend provenance checking to the spike's separately installed dependencies.
- Resolve M4 review findings with a neutral native-profile preflight, complete
  package output protection and mandatory evidence-category validation. Preserve
  the original review and run history; acceptance requires fresh independent review.

## 3.0.3 — Unreleased

- M3: migrate all thirteen skills into the canonical `.agents/skills` library;
  retain thin legacy redirects and expose the same content to both native hosts.
- Add consumer adoption with conflict preflight, instruction/configuration merges,
  explicit environment selection, immutable package links and migration receipts.
- Move review, prerequisite, tracker and hook state to consumer storage; preserve
  imported team libraries and existing application/framework code.
- Add bounded local-source validation with assertions, optional external references
  and source fingerprints, without ADO configuration or operation execution.
- Update installed tracker, metrics, hooks and legacy ADO root selection. Keep
  sequential execution and reviewed knowledge promotion explicit.
- No M4 spike, host adapter, executor, public push or release is included.

## 3.0.2 — Unreleased

- M2 only: maintain `element-locators` in `.agents/skills` and retain thin redirects
  at its existing Claude paths. The other twelve skills remain in place.
- Add a Claude plugin manifest pointing directly to the canonical skill directory.
- Add separate package, consumer and run roots with overwrite/escape refusal fixtures.
- Add native discovery and six-case host proof tooling with reference-read evidence,
  immutable-package checks and semantic comparison. See the M2 validation record for
  actual host outcomes; packaging or process exit alone is not a behavior proof.
- Complete the six-case Windows proof through both native hosts. Record an explicit
  available Claude model per attempt when its configured alias is unsupported; normalize
  native Windows path escaping without relaxing file-content evidence requirements.
- No bulk migration, production host adapters or executors are included.

## 3.0.1 — Unreleased

- M1: replace private ledgers and prerequisites with clean templates; sanitize
  documentation, examples and private script defaults.
- Add repeatable syntax, JSON, link, convention, privacy, secret and provenance gates.
- Require meaningful convention scope; expose applied-rule counts and fail-on-warning mode.
- Correct example assertion reporting, dependencies and runtime support documentation.
- Apply MIT after owner rights confirmation; inventory dependency licenses and source provenance.
- Inspect npm package contents and exclude installed dependencies and protected recovery data.
- Publication remains blocked by unresolved credential remediation and requires explicit authorization.
- No skill relocation, new host adapter or executor implementation is included.

## 3.0.0

Added reusable technical example utilities, richer locator/validation guidance,
independent review conventions and per-case test-data guidance.

## 2.6.0

Added traceability/verification artifact checks and additional mechanical conventions.

## 2.5.0

Expanded technical utility guidance and generated-test validation practices.

## 2.4.x

Added named timeout tiers, assertion-message helpers and reporting conventions.

## 2.3.0

Expanded progress tracking and pipeline observability.

## 2.2.0

Refined reusable workflow and example guidance.

## 2.1.0

Standardized the framework's source-layer layout.

## 2.0.x

Separated convention skills and process responsibilities.

## 1.x

Initial versioned package structure and adoption protocol.
