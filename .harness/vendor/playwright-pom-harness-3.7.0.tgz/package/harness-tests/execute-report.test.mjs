import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, writeFileSync, unlinkSync, existsSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {executionFixture, executeApi} from './fixtures/execute.mjs';
import {collectExecution, writeExecutionReport, defectFingerprint, diagnosticSignature, executionDefects} from '../scripts/lib/execute/report.mjs';
import {executionOverview, renderExecutionHtml} from '../scripts/lib/execute/report-html.mjs';
import {executionReportView, reportCondition} from './fixtures/execute-report.mjs';
import {readExecution} from '../scripts/lib/execute/storage.mjs';
import {fingerprint} from '../scripts/lib/execution-core/data.mjs';

test('user-facing execution HTML contains useful results without debugging metadata', () => {
  const view = executionReportView(['FAIL']);
  view.runs[0].conditions[0].provenance.results[0].actual = 500;
  view.runs[0].conditions[0].provenance.results[0].expected = 200;
  const html = renderExecutionHtml(view);
  assert.match(html, /Expected/); assert.match(html, /Actual result/); assert.match(html, /500/); assert.match(html, /200/);
  assert.doesNotMatch(html.slice(html.indexOf('<body>'), html.indexOf('<script>')), /Raw data|Evidence identifiers|Additional execution evidence|Operation provenance|Evidence inventory|SHA256|fingerprint|Verification rollup|No diagnostics|execute-fixture|artifact-1|<code class="run-id"/i);
});

test('execution report omits obsolete navigation, counting instructions and empty exclusions', () => {
  const view = executionReportView(['FAIL']);
  const html = renderExecutionHtml(view);
  assert.doesNotMatch(html, /Core reports?|How verification methods are counted|Source exclusions/);
  view.source.excluded = [{id: 901, reason: 'parameters-without-data'}, {id: 902, reason: '<img src=x onerror=alert(1)>'}];
  const populated = renderExecutionHtml(view);
  assert.match(populated, /Cases excluded from execution · 2/);
  assert.match(populated, /901/); assert.match(populated, /Parameter values are missing/);
  assert.match(populated, /&lt;img src=x/); assert.doesNotMatch(populated, /<img src=x/);
});

test('execution writes one case report with evidence and no per-attempt report directories', async t => {
  const f = await executionFixture(t); f.apiStep(); f.freeze(); await executeApi(f);
  const report = writeExecutionReport(f.roots, f.executionId);
  assert.equal(report.status, 'WRITTEN');
  assert.equal(existsSync(join(f.roots.projectRoot, report.directory, 'runs')), false);
  const html = readFileSync(join(f.roots.projectRoot, report.html), 'utf8');
  assert.doesNotMatch(html, /Operation provenance|Evidence inventory/);
  assert.match(html, /<a href="summary.md">Summary/); assert.match(html, /<a href="defects.md">Defects/);
});
test('collapsed case rows explain failures and blockers without requiring raw logs', () => {
  const view = executionReportView(['FAIL', 'BLOCKED', 'BLOCKED']);
  view.scenarios[1].reason = 'Required customer fixture is unavailable.';
  view.scenarios[1].stage = 'PREPARE';
  view.scenarios[1].nextAction = 'Provision the customer fixture, then resume.';
  view.runs[1].conditions = [];
  view.runs[2].conditions = [];
  const html = renderExecutionHtml(view);
  const summaries = [...html.matchAll(/<details class="case-row"[^>]*><summary>([\s\S]*?)<\/summary>/g)].map(match => match[1]);
  assert(summaries[0].includes('class="case-reason"'), 'Failure reason must be visible in the collapsed case row.');
  assert(summaries[0].includes('The expected panel is unavailable'));
  assert(summaries[1].includes('Required customer fixture is unavailable.'));
  assert(html.includes('Provision the customer fixture, then resume.'));
  assert(summaries[2].includes('Reason unavailable; investigation is needed.'));
});

test('a failed case followed by an interrupted rerun keeps its authoritative failure reason visible', async t => {
  const f = await executionFixture(t, {handler: (req, res) => {res.writeHead(500); res.end('{}');}});
  f.apiStep(); f.freeze(); await executeApi(f);
  const interrupted = await executeApi(f, {explicitRerun: true});
  unlinkSync(join(interrupted.roots.runRoot, 'observations.json')); // Simulate a missing final assessment after interruption.
  const report = writeExecutionReport(f.roots, f.executionId), html = readFileSync(join(f.roots.projectRoot, report.html), 'utf8');
  assert.equal(report.scenarios[0].status, 'FAIL');
  const summary = html.match(/<details class="case-row"[^>]*><summary>([\s\S]*?)<\/summary>/)[1];
  assert(summary.includes('Failed check:'), 'The FAIL row must explain the authoritative failed check.');
  assert(summary.includes('500')); assert(!summary.includes('interrupted'));
  assert(html.includes('Execution was interrupted before a final assessment was recorded.'));
});

test('captured unfrozen executions report blockers while preserving unexecuted cases', async t => {
  const f = await executionFixture(t), captured = readExecution(f.roots, f.executionId);
  const notes = {version: 1, sourceFingerprint: fingerprint(captured.source), cases: [{scenarioId: captured.source.scenarios[0].id, stage: 'REFINE', reason: 'The required fixture is unavailable.', nextAction: 'Provision the fixture before execution.'}]};
  const report = writeExecutionReport(f.roots, f.executionId, {notes});
  assert.equal(report.status, 'WRITTEN'); assert.equal(report.scenarios[0].status, 'BLOCKED');
  assert.equal(Boolean(readExecution(f.roots, f.executionId).execution.freezeFingerprint), false);
  const html = readFileSync(join(f.roots.projectRoot, report.html), 'utf8'); assert(html.includes(notes.cases[0].reason));
  assert(!html.includes('NaN')); assert(!html.includes('Infinity'));
});

test('readiness blockers name missing environment references without reading their values into reports', async t => {
  const f = await executionFixture(t); f.apiStep();
  f.refinement.scenarios[0].steps[0].inputs = [{name: 'fixture', source: 'env:REPORT_REQUIRED_FIXTURE'}]; f.freeze();
  const report = writeExecutionReport(f.roots, f.executionId);
  assert.equal(report.scenarios[0].status, 'BLOCKED'); assert(report.scenarios[0].reason.includes('REPORT_REQUIRED_FIXTURE'));
  assert.equal(report.scenarios[0].stage, 'PREPARE'); assert.equal(report.scenarios[0].history.length, 0);
});
test('report ignores claimed result JSON, labels integrity failures, and accepts an explicit valid replacement', async t => {
  const f = await executionFixture(t); f.apiStep(); f.freeze(); const first = await executeApi(f);
  writeFileSync(join(first.roots.runRoot, 'result.json'), '{"status":"FAIL"}'); assert.equal(collectExecution(f.roots, f.executionId).scenarios[0].status, 'PASS');
  writeFileSync(join(first.roots.runRoot, first.result.evidence[0].path), 'tampered'); let view = collectExecution(f.roots, f.executionId); assert.deepEqual(view.integrityFailures, ['tc-101-r1']); assert.equal(view.scenarios[0].status, null);
  const report = writeExecutionReport(f.roots, f.executionId); assert(readFileSync(join(f.projectRoot, report.directory, 'index.html'), 'utf8').includes('INTEGRITY FAILURE (no verdict)'));
  await executeApi(f, {explicitRerun: true}); view = collectExecution(f.roots, f.executionId); assert.equal(view.scenarios[0].status, 'PASS'); assert.equal(view.integrityFailures.length, 0); assert(view.scenarios[0].history[0].supersededIntegrity);
});
test('valid historical FAIL dominates a later valid PASS and HTML is escaped with CSP', async t => {
  let status = 500; const f = await executionFixture(t, {handler: (req, res) => {res.writeHead(status); res.end('{}');}, cases: [{id: 101, rev: 1, title: '<script>window.bad=1</script>', parameters: null, steps: [{action: 'Read status', expected: 'Status is 200'}]}]}); f.apiStep(); f.freeze(); await executeApi(f); status = 200; await executeApi(f, {explicitRerun: true}); assert.equal(collectExecution(f.roots, f.executionId).scenarios[0].status, 'FAIL');
  const report = writeExecutionReport(f.roots, f.executionId), html = readFileSync(join(f.projectRoot, report.directory, 'index.html'), 'utf8'); assert(html.includes("default-src 'none'")); assert(!html.includes('<script>window.bad=1</script>')); assert(html.includes('&lt;script&gt;'));
  const script = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)]; assert.equal(script.length, 1);
  assert(html.includes(`script-src 'sha256-${createHash('sha256').update(script[0][1]).digest('base64')}'`));
  assert(!/script-src[^;]*unsafe-inline/.test(html));
  assert(html.includes('Expected value')); assert(html.includes('500'));
});
test('defect identity is independent of iteration, environment, values and execution identity', () => {
  const source = {organizationUrl: 'https://ado.example.test', project: 'demo'}, base = {kind: 'expectation', caseId: 101, sourceStep: 1, expectedIndex: 1, conditionIndex: 1, conditionTemplate: 'Value is @name'};
  assert.equal(defectFingerprint(source, {...base, iteration: 1, value: 'A', runId: 'one'}), defectFingerprint(source, {...base, iteration: 2, value: 'B', runId: 'two'})); assert.notEqual(defectFingerprint(source, base), defectFingerprint(source, {...base, conditionIndex: 2}));
});

test('diagnostic grouping normalizes numeric and UUID path identities', () => {
  assert.equal(diagnosticSignature('/api/v1/records/123'), diagnosticSignature('/api/v1/records/456'));
  assert.equal(diagnosticSignature('/records/991a3162-b359-4362-ac88-76d0d6368f00'), diagnosticSignature('/records/ab7a3162-b359-4362-ac88-76d0d6368f01'));
});

test('diagnostic signatures template string parameters, encoded values and environment origins', () => {
  for (const template of ['/users/VALUE', 'Request https://ENV.example.test/users/VALUE failed', 'Unable to load "VALUE"']) {
    const first = diagnosticSignature(template.replaceAll('VALUE', 'alice').replace('ENV', 'qa'), {bindings: {user: 'alice'}});
    const second = diagnosticSignature(template.replaceAll('VALUE', 'bob').replace('ENV', 'staging'), {bindings: {user: 'bob'}});
    assert.equal(first, second);
  }
  assert.equal(diagnosticSignature('/users/Alice%20Smith', {bindings: {user: 'Alice Smith'}}), diagnosticSignature('/users/Bob%20Jones', {bindings: {user: 'Bob Jones'}}));
  assert.equal(diagnosticSignature('/users/alice', {bindings: {user: 'a'}}), '/users/alice');
  assert.equal(diagnosticSignature('/records/created-one', {values: ['created-one']}), diagnosticSignature('/records/created-two', {values: ['created-two']}));
  assert.equal(diagnosticSignature('/reviewers/alice', {bindings: {owner: 'alice', reviewer: 'alice'}}), diagnosticSignature('/reviewers/carol', {bindings: {owner: 'bob', reviewer: 'carol'}}));
});

test('large valid API assertions remain assessed FAIL instead of an integrity failure', async t => {
  const f = await executionFixture(t, {steps: [{action: 'Read value', expected: 'Value is "ok"'}], handler: (req, res) => {res.writeHead(200, {'content-type': 'application/json'}); res.end(JSON.stringify({value: 'x'.repeat(100000)}));}}), step = f.apiStep();
  step.expectations[0].conditions[0].expected.value = 'ok'; Object.assign(step.operation.checks[0], {select: {from: 'json', path: ['value']}, equals: 'ok'});
  f.freeze(); const run = await executeApi(f); assert.equal(run.result.status, 'FAIL'); assert(run.result.evidence.some(record => record.kind === 'assertion' && record.bytes > 64 * 1024));
  const report = writeExecutionReport(f.roots, f.executionId); assert.equal(report.scenarios[0].status, 'FAIL'); assert.equal(report.scenarios[0].state, 'ASSESSED');
  assert.match(report.directory, /^reports\/harness\/execution-\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}Z(?:-\d{3,})?$/);
  assert(!report.directory.includes('/execute-execute-')); assert.equal(report.executionId, f.executionId);
});

test('diagnostic defects merge parameterized iterations through the report caller', () => {
  const source = {organizationUrl: 'https://ado.example.test', project: 'demo', scenarios: ['alice', 'bob'].map((user, index) => ({id: `case-${index}`, caseId: 101, title: 'Read user', bindings: {user}}))};
  const freeze = {scenarios: source.scenarios.map(scenario => ({id: scenario.id, steps: [{id: 's1', sourceSteps: [1]}]}))};
  const runs = source.scenarios.map(scenario => ({scenarioId: scenario.id, runId: `run-${scenario.id}`, state: 'ASSESSED', conditions: [], result: {scenarios: [{attempts: []}]}, diagnostics: [{stepId: 's1', evidenceId: `e-${scenario.id}`, entries: [{kind: 'request', path: `/users/${scenario.bindings.user}`}]}]}));
  const groups = executionDefects({source, freeze, runs}); assert.equal(groups.length, 1); assert.equal(groups[0].occurrences.length, 2);
});

test('overview keeps historical review separate and uses supplied source-expectation rollups', () => {
  const view = executionReportView(['PASS', 'FAIL']);
  view.scenarios[0].methods = {checked: 0, observed: 0, mixed: 1, unresolved: 0};
  const historical = {...view.runs[0], runId: 'run-earlier', conditions: [reportCondition('INDETERMINATE')], result: {...view.runs[0].result, status: 'NEEDS_REVIEW'}};
  view.runs.unshift(historical); view.scenarios[0].history.unshift({runId: historical.runId, state: 'ASSESSED', verdict: 'NEEDS_REVIEW'});
  assert.deepEqual(executionOverview(view, 7), {total: 2, passed: 1, failed: 1, review: 0, attempts: 3, defectGroups: 7, passRate: 50,
    outcomes: [{status: 'PASS', count: 1, percentage: 50}, {status: 'FAIL', count: 1, percentage: 50}]});
  const before = JSON.stringify(view), html = renderExecutionHtml(view, {defectCount: 7});
  assert.equal(JSON.stringify(view), before); assert(html.includes('Earlier attempt')); assert(!html.includes('run-earlier')); assert(!html.includes('1 mixed')); assert.equal(view.scenarios[0].methods.mixed, 1);
  assert.equal((html.match(/data-chart-status=/g) ?? []).length, 2); assert(!html.includes('data-chart-status="NEEDS_REVIEW"'));
  assert(html.includes('Insufficient evidence')); assert(html.includes('defects.md'));
});

test('empty and uniform outcome reports have meaningful rates and actual chart categories', () => {
  const empty = executionReportView([]), emptyHtml = renderExecutionHtml(empty);
  assert.equal(executionOverview(empty, 0).passRate, null); assert(emptyHtml.includes('No test cases recorded')); assert(emptyHtml.includes('data-metric="pass-rate">—'));
  assert(!emptyHtml.includes('data-chart-status=')); assert(!emptyHtml.includes('NaN')); assert(!emptyHtml.includes('Infinity'));
  for (const [status, rate] of [['PASS', '100.0%'], ['FAIL', '0.0%']]) {
    const html = renderExecutionHtml(executionReportView([status, status]));
    assert(html.includes(`data-metric="pass-rate">${rate}`)); assert.equal((html.match(/data-chart-status=/g) ?? []).length, 1);
    assert(html.includes(`data-chart-status="${status}" data-count="2"`));
  }
  const mixed = renderExecutionHtml(executionReportView(['PASS', 'FAIL', 'NEEDS_REVIEW', 'BLOCKED', 'NOT_RUN', 'INTEGRITY_FAILURE', 'SKIPPED']));
  assert.equal((mixed.match(/data-chart-status=/g) ?? []).length, 7); assert(mixed.includes('INTEGRITY FAILURE (no verdict)')); assert(mixed.includes('data-metric="pass-rate">14.3%'));
});

test('user results remain escaped and screenshots deduplicate without exposing technical records', () => {
  const view = executionReportView(['FAIL']);
  const payload = '</script><img src=x onerror=alert(1)>' + 'long '.repeat(200);
  view.scenarios[0].title = payload; view.runs[0].conditions[0].provenance.results[0].actual = payload;
  const entry = {kind: 'request', path: '/records/1', status: 500, notice: false};
  view.runs[0].diagnostics = [{stepId: 'step-1', evidenceId: 'd1', entries: [entry, {...entry}], family: 'browser', legacy: false}];
  const src = 'data:image/png;base64,iVBORw0KGgo=';
  const screenshots = new Map([['run-1', [{id: 'artifact-1', src}, {id: 'artifact-2', src}]]]);
  const html = renderExecutionHtml(view, {screenshots});
  assert(!html.includes('<img src=x')); assert(html.includes('&lt;/script&gt;&lt;img'));
  assert.equal((html.match(/data:image\/png;base64,/g) ?? []).length, 1);
  assert(!html.includes('artifact-1')); assert(!html.includes('artifact-2')); assert(!html.includes('recorded occurrences'));
  assert(html.includes('Screenshot 1')); assert(html.includes('Screenshot 2')); assert.equal(view.runs[0].diagnostics[0].entries.length, 2);
  assert(!html.includes('data-raw-json')); assert.equal(view.runs[0].conditions[0].provenance.results[0].actual, payload);
  assert(!html.includes('<time')); assert(!html.includes('Environment <strong>'));
});

test('API proof presentation preserves false, zero, null, redaction and original proof fields', () => {
  const view = executionReportView(['FAIL']); view.runs[0].conditions[0].provenance = null;
  for (const actual of [false, 0, null, '[REDACTED]']) {
    const proof = {check: 'status', expected: true, actual, passed: false, method: 'original-field'};
    const html = renderExecutionHtml(view, {assertionEvidence: new Map([['run-1:artifact-1', proof]])});
    assert(html.includes('Actual result')); assert(!html.includes('original-field')); assert(!html.includes('&quot;passed&quot;: false')); assert.equal(proof.actual, actual);
    assert(!html.includes('No actual value is recorded'));
    assert(html.includes(`<dd>${actual === null ? 'null' : String(actual)}</dd>`));
  }
});
