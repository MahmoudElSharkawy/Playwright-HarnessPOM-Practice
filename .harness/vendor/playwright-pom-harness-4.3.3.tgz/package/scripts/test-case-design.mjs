#!/usr/bin/env node
import {projectArgument, consumerPath} from './lib/consumer-paths.mjs';
import {readBounded} from './lib/execute/storage.mjs';
import {prepareDesign, saveDesign, assessDesign, rejectDesign, readDesign, designView, stateToDesignView, compactDesignResult, designHandoff} from './lib/test-case-design/index.mjs';
import {previewDesign, publishDesign, reconcileDesign} from './lib/test-case-design/delivery.mjs';
import {discoverDesignCases} from './lib/test-case-design/sources.mjs';

const usage = `pom-harness test-case-design <prepare|read|review|edit|assess|reject|discover|preview|publish|reconcile|handoff>
  prepare --id <design> --input <consumer-source-selection-json>
  review|edit --id <design> --input <complete-proposal-json> [--notes <review-notes-json>]
  assess --id <design> --input <independent-assessment-json> [--notes <review-notes-json>]
  read --id <design> [--notes <review-notes-json>]
  reject --id <design>
  discover --id <design> --input <query-groups-or-selected-ids-json>
  reconcile --id <design> [--input <user-confirmed-id-json>]
  preview --id <design> [--selected <ID,ID>] [--fields <publication-fields-json>]
  handoff --id <design> [--selected <ID,ID>]
  publish --id <design> --approval <exact-preview-fingerprint>
All commands accept --format <json|compact>; json is the default.
All state belongs to the consumer. Compact output supplies the chat summary and current reviewFile.
Default JSON retains complete source, case details and renderings for explicit review/debugging.
Review notes are optional {gaps?, suggestions?} Markdown strings, never case or approval input.
Publication requires current source, actual independent review and exact approval.
Reconcile uncertain operations before resuming. This command never executes tests.`;
try {
  const {roots, args} = projectArgument(), [command, ...rest] = args, options = {};
  if (['help', '--help'].includes(command)) {console.log(usage); process.exit(0);}
  const allowed = {prepare: ['id', 'input'], review: ['id', 'input', 'notes'], edit: ['id', 'input', 'notes'], assess: ['id', 'input', 'notes'], read: ['id', 'notes'], reject: ['id'], discover: ['id', 'input'], reconcile: ['id', 'input'], preview: ['id', 'selected', 'fields'], publish: ['id', 'approval'], handoff: ['id', 'selected']}[command];
  if (!allowed) throw new Error(usage);
  for (let index = 0; index < rest.length; index += 2) {
    const key = rest[index]?.replace(/^--/, '');
    if (!rest[index]?.startsWith('--') || ![...allowed, 'format'].includes(key) || !rest[index + 1] || rest[index + 1].startsWith('--') || options[key]) throw new Error('Unknown, duplicate or incomplete option.\n' + usage);
    options[key] = rest[index + 1];
  }
  if (!options.id) throw new Error('--id is required.');
  if (options.format !== undefined && !['json', 'compact'].includes(options.format)) throw new Error('--format must be json or compact.');
  const input = () => {if (!options.input) throw new Error('--input is required.'); return readBounded(consumerPath(roots, options.input));};
  const selection = options.selected === undefined ? {} : {selected: options.selected.split(',')};
  let result;
  if (command === 'prepare') result = await prepareDesign(roots, options.id, input());
  else if (command === 'review' || command === 'edit') result = stateToDesignView(roots, saveDesign(roots, options.id, input()), undefined, {notes: options.notes});
  else if (command === 'assess') result = stateToDesignView(roots, assessDesign(roots, options.id, input()), undefined, {notes: options.notes});
  else if (command === 'reject') result = rejectDesign(roots, options.id);
  else if (command === 'read') result = designView(roots, options.id, undefined, {notes: options.notes});
  else if (command === 'discover') result = await discoverDesignCases(roots, readDesign(roots, options.id), input());
  else if (command === 'preview') result = await previewDesign(roots, options.id, {...selection, ...(options.fields ? {fields: readBounded(consumerPath(roots, options.fields))} : {})});
  else if (command === 'publish') result = await publishDesign(roots, options.id, {approval: options.approval});
  else if (command === 'reconcile') result = await reconcileDesign(roots, options.id, options.input ? {confirmation: input()} : {});
  else result = await designHandoff(roots, options.id, selection);
  console.log(JSON.stringify(options.format === 'compact' && command !== 'discover' ? compactDesignResult(result) : result, null, 2));
  if (['incomplete', 'reconciliation-required'].includes(result?.mode)) process.exitCode = 1;
} catch (error) {console.error('test-case-design: ' + error.message); process.exitCode = 1;}
