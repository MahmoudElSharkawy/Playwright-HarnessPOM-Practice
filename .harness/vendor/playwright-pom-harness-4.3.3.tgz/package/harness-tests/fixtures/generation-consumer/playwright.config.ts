import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  workers: 1,
  retries: 0,
  use: { browserName: 'chromium', channel: 'chrome', headless: true },
  projects: [{ name: 'proof' }]
});
