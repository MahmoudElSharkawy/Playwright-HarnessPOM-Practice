# Database runtimes

SQL Server, PostgreSQL and MySQL share definitions, typed bindings, attempts, effects,
evidence and lifecycle assessment. Native SQL/types stay driver-specific; there is
no dialect translator, ORM or required query builder. Source SQL from consumer team
queries first and follow the [service-class skill](../../.agents/skills/service-classes/SKILL.md).

## Targets and principals

Select an explicit database target through the environment; for example:

```json
{
  "api": {},
  "databases": {
    "qa-db": {
      "engine": "sqlserver",
      "server": "database.example.com",
      "port": 1433,
      "database": "SyntheticTesting",
      "schema": "fixtures",
      "connectionRef": "env:HARNESS_DB_CREDENTIAL",
      "encrypt": true,
      "trustServerCertificate": false
    }
  }
}
```

PostgreSQL uses `engine: "postgresql"`, appropriate destination/database and normally
port 5432. Its operation definitions explicitly declare the engine; omission means
SQL Server. Mismatch fails before credentials resolve. Execution needs server,
database and schema even if an older configuration-only target can still load.

MySQL uses `engine: "mysql"`, MySQL 8.4, and default port 3306. Its schema is the
database: omit `schema` or set it to the same value. Other MySQL versions and
MariaDB are outside this initial support boundary. Definitions must declare
`engine: "mysql"`; existing definitions still default to SQL Server.

Default credentials resolve the reference from shell environment or consumer `.env`
as JSON containing only user/password. Custom resolvers cannot override destination,
schema or TLS. Authentication stays in memory. Encryption/certificate verification
default on; disposable local proofs select their fixture policy explicitly.
Verified MySQL TLS requires a DNS server name and checks both its certificate chain
and hostname. Literal IP targets require an explicit unencrypted or trusted-certificate
fixture policy because the pinned driver omits their TLS server name.
SELECT/DML/exploration capabilities follow [configuration](../configuration.md).

Use an account with the database permissions required by the selected operations.
Broader grants, inherited roles and ownership are accepted. The harness still
requires operation authorization and checks each statement's direct references
against the selected database and schema before dispatch. The database enforces
its own authentication and permissions.

Qualify application objects with the configured schema spelling or leave their
names unqualified. The runtime resolves unqualified persistent objects to the
configured scope, independently of the account's default schema or search path.
Use the same spelling for references to aliases and CTE names. The runtime refuses
ambiguous names before dispatch. System schemas, linked servers,
cross-database access and references whose scope cannot be established are refused.
SQL Server resolves relation names to visible application objects and excludes
catalog aliases and synonyms. MySQL checks the referenced tables and requires
InnoDB base tables. Unrelated tables and views do not affect the operation.

Database owners remain responsible for views, functions, triggers and ownership
chains, including their downstream effects and native row-security policies.
The harness checks direct SQL references. Isolation of database-owned behavior
requires controls at the database.

## Schema-backed query discovery

During `execute-test` refinement or `automate-test` refinement/exploration, first
search existing business methods, applicable supplied queries and reviewed DB
knowledge. When the selected scenario still needs a lookup or persisted-state
check, an empty `resources/Queries/` does not block discovery. Credentials alone
grant nothing: the selected target must permit both `dbSelect` and `dbExploration`.
Keep suitable API preparation, required GUI journeys and UI-specific checks.

Initial discovery supports **SQL Server ordinary tables and exact unique-key
SELECTs**. PostgreSQL/MySQL automatic discovery and
durable generated MySQL services are unsupported. Joins, views, functions,
ambiguous keys, unsupported native types and automatic mutation recipes remain
explicit gaps. Metadata relationships are evidence, never inferred join semantics.

`createDatabaseRuntime(...).inspectSchema({target, operationId, invocationId,
tables, phase})` inspects one to eight explicitly selected relevant table names.
When names are unknown, supply `tableHint` instead of `tables`: a literal term of
3–128 characters from the selected scenario. A parameterized catalog search returns
at most eight matching names in the configured schema, then inspects those tables.
No matches or more than eight matches is an explicit gap. Matches do not establish
business meaning; choose the exact relevant table from verified source evidence.
The invocation must serve a frozen scenario expectation. The shared sequential
callback exposes the same method at `context.database.inspectSchema`. Fixed
catalog requests use the existing SQL Server driver, destination verification,
typed parameters, cancellation and result limits. Callers select only a table or
hint. Each run permits at most eight inspections
and eight distinct target/table pairs, with a 10-second inspection ceiling, fewer
than 512 metadata rows per table and 256 KiB overall. No application rows are read.

The returned `{schema, evidence}` receipt binds run/scenario, target fingerprint,
engine, database/schema, columns, native types, ordered unique keys and foreign
keys. It is registered evidence separate from business assertions; metadata never
creates a passing case. Missing permissions or incomplete/unsupported metadata
produce a specific `DB_SCHEMA_*` gap. Use source-bound case notes for unresolved
discovery and continue unrelated supported cases.

The library interfaces in `scripts/lib/database/discovery.mjs` derive a candidate
from a live receipt, explicit key/output mapping and source artifact. Derivation
generates one parameterized SELECT with a complete nonnullable unique key,
explicit selected columns and native parameter types. It accepts no caller SQL,
row samples, SQL comments or literal expected values. Check expectations remain
frozen scenario inputs; current IDs remain run state. Review must establish exact
identity correlation, business status meanings, tenant/soft-delete semantics and
source-defined expectations; one observed row cannot establish any of them.

Candidates live under `.harness/knowledge-candidates/db/records/`. Review requires
a retained artifact covering purpose, target/schema, SQL, inputs, extraction and
semantics, plus a successful execution of the matching operation through the
configured runtime with reliable source-grounded checks and complete required
lifecycle. The authoritative ordinary operation record lives under
`.harness/knowledge/db/records/`. Promotion derives
`resources/Queries/<application>-discovered.md`, preserving supplied exports,
equivalent-definition deduplication, distinct variants, and previous provenance.
An exclusive lock and flushed atomic replacement prevent partial publication;
an interrupted lock is a recovery gap, never permission to steal another writer.
Conflicting operation identities and externally changed documents fail visibly.

Fresh reuse requires a new live schema receipt for the selected run and checks
every retained source, metadata, review and verification artifact. Missing/changed
evidence, target drift or relevant schema drift invalidates reuse until resolved.
Markdown is documentation, never executable SQL or an independent authority.
Review prose is an explicit sanitization responsibility; source contents and
actual inputs/results are not copied into durable knowledge.

Library API example (values and expectations are already frozen from the source):

```js
import {deriveDbCandidate, reviewDbCandidate, readReviewedDb,
  promoteDiscoveredQueries} from 'playwright-pom-harness/scripts/lib/database/discovery.mjs';

const schema = await runtime.inspectSchema({target: 'orders-db',
  operationId: 'verify-order', invocationId: 'verify-order', tableHint: 'Order'});
const candidate = deriveDbCandidate(run, roots, {schema,
  operationId: 'verify-order', invocationId: 'verify-order', table: 'Orders',
  purpose: 'Read the selected order state', key: [{column: 'Id', input: 'orderId'}],
  columns: ['Id', 'Status'], checks: [
    {id: 'one-order', input: 'expectedCount'},
    {id: 'order-state', column: 'Status', input: 'expectedStatus'}
  ], source: {artifact: '.harness/sources/order.json', scenarioId: 'order-case'}});
// Review the candidate, then freeze candidate.operation in a validation run.
// Execute it with typed scenario inputs through createDatabaseRuntime.
const reviewed = reviewDbCandidate(roots, {candidateId: candidate.id,
  review: {reviewer: 'contract-reviewer', artifact: '.harness/state/order-review.md',
    purpose: 'Read the selected order state', inputs: 'Exact selected order identity',
    extraction: 'Explicit identity and status fields; no result samples retained',
    semantics: 'Source establishes identity, status meanings and applicable tenant/deletion rules'},
  validation: {run: validationRun, roots: validationRoots, observations, attemptId}});
await promoteDiscoveredQueries(roots, {application: 'orders', reviewedIds: [reviewed.id]});
// A later invocation inspects the relevant schema again before reuse.
const reusable = readReviewedDb(roots, reviewed.id, {run: laterRun, roots: laterRoots, schema: freshSchema});
```

`readDbCandidate` / `listDbCandidates` inspect candidates; `listReviewedDbs` is
historical inspection only. Only `readReviewedDb` with a current live receipt
establishes schema compatibility for reuse. The example names and mapping are
illustrative, not evidence that a consumer has an `Orders` table.

Current selections retain an integrity-bound receipt under
`.harness/state/db-reuse/records/`, including the fresh schema evidence and current
run/scenario. Reports distinguish that selection from successful SQL execution and
bind review labels to the exact candidate. Historical knowledge alone cannot claim
reuse in a later run; missing or changed evidence remains a separate visible gap.

Manual execution completes this work before freezing operation/check provenance;
a missing operation discovered later returns to refinement. It may save knowledge
but generates no POM code. Automation derives a normal `Dbs<Domain>` operation
through the existing `DBActions` facade, promotes before generation freeze, and
retains independent framework review and two fresh scoped green runs. Required
seed/cleanup/restoration still needs an existing supported operation. Discovery
summaries and library paths never change case verdicts or delivery readiness.

## Definitions and parameter binding

Import `defineDatabaseOperation`/`createDatabaseRuntime` from
`playwright-pom-harness/scripts/lib/database/index.mjs`. A SQL Server definition:

```js
const create = defineDatabaseOperation({
  id: 'create-item', target: 'qa-db',
  source: {kind: 'inline', reference: 'item-scenario', version: '1'},
  sql: 'INSERT INTO fixtures.Items (Id, Label) OUTPUT INSERTED.Id VALUES (@recordId, @label)',
  parameters: [
    {name: 'recordId', type: 'int', input: 'recordId'},
    {name: 'label', type: 'nvarchar', length: 200, input: 'label'}
  ],
  checks: [{id: 'created', select: {from: 'affectedRows', path: []}, equals: 1}],
  affectedRows: {min: 1, max: 1},
  extract: [{name: 'recordId', type: 'number', sensitivity: 'public',
    select: {from: 'rows', path: [0, 'Id']}}]
});
```

Freeze it with typed values and exact expectations using `createRun`, then execute
`runtime.execute({operation, invocationId, phase, inputs, ...})`. This is a definition,
not a complete runnable test. Roots separate immutable package storage from the fresh
consumer run. One runtime handles one scenario; `selectOutput` chooses explicit outputs,
and `finish()` validates scope/evidence/lifecycle. Prefer the
[sequential lifecycle](execution-model.md#sequential-lifecycle) for mixed work.

SQL Server uses native `Request.input` and `@name`; PostgreSQL `$1`, `$2`, … match
the ordered parameter array and pg's values. MySQL uses ordered native `?` parameters
through mysql2 prepared execution. Values never rewrite SQL text:

```js
const read = defineDatabaseOperation({
  id: 'read-item', target: 'qa-db', engine: 'postgresql',
  source: {kind: 'inline', reference: 'spec-read-item', version: '1'},
  sql: 'SELECT "Label" FROM fixtures."Items" WHERE "Id"=$1',
  parameters: [{name: 'recordId', input: 'recordId', type: 'integer'}],
  checks: [{id: 'label-matches', select: {from: 'rows', path: [0, 'Label']},
    equals: {$input: 'label'}}]
});
```

Bindings preserve type, sensitivity and producer. Undefined, nonfinite, coerced or
overlong values fail. Selectors use rows/rowCount/affectedRows. MySQL additionally
supports scalar `insertId` (empty path), an exact string for the first generated
AUTO_INCREMENT identity, only when INSERT generated a nonzero identity. For example:

```js
const createMysql = defineDatabaseOperation({
  id: 'create-mysql-item', target: 'mysql-db', engine: 'mysql',
  source: {kind: 'inline', reference: 'item-scenario', version: '1'},
  sql: 'INSERT INTO Items (Label) VALUES (?)',
  parameters: [{name: 'label', input: 'label', type: 'varchar', length: 200}],
  checks: [{id: 'created', select: {from: 'affectedRows', path: []}, equals: 1}],
  affectedRows: {min: 1, max: 1},
  extract: [{name: 'recordId', type: 'string', sensitivity: 'public',
    select: {from: 'insertId', path: []}}]
});
```

Bind the extracted identity as `unsigned bigint` to later reads or cleanup DELETEs.
Catalog/helper/inline
definitions freeze before execution; enabled exploration has identical controls.
Dynamic identifiers use lexical `{{slot}}` markers and an allowlist such as
`identifiers: {slot: {input: 'tableName', allowed: ['Items']}}`. Engines quote single
allowed identifiers; markers in comments/literals stay untouched. Schema stays fixed.

## Types and completeness

| Engine | Binding/result rules |
|---|---|
| SQL Server | int, bigint exact strings, bit, float, bounded decimal, varchar/nvarchar, varbinary hex, uniqueidentifier and datetime2 canonical UTC milliseconds; null supported |
| PostgreSQL | Bounded text/varchar/bytea/jsonb, integer/bigint, boolean, double precision/numeric, date/timestamp/timestamptz, uuid/xid; precision/scale and byte lengths explicit |
| MySQL | int, signed/unsigned bigint exact strings, boolean, double, bounded decimal, text/varchar, varbinary hex, date/datetime/timestamp and structured json; null supported |

Use nvarchar for Unicode. SQL Server result dates/bytes/bigint become ISO/hex/exact
text; datetime2/time preserve 100-nanosecond ticks, datetimeoffset normalizes UTC.
High-precision decimal/money needs textual SQL projection; XML/variant/spatial and
multiple resultsets are unsupported.

PostgreSQL per-query parsers ignore global overrides: bigint/numeric/xid remain exact
text, binary hex, temporal values preserve microseconds (UTC for timestamptz).
JSON/JSONB returns exact JSON text; project supported fields explicitly for arrays/
unlisted types. Duplicate fields, unsafe names and nonfinite/unsupported values fail.

MySQL text/binary/JSON bindings require byte-length bounds; decimal requires
precision (1–65) and scale (0–30, at most precision). BIGINT and DECIMAL results
remain exact strings. JSON results remain exact JSON text, binary becomes hex,
BOOLEAN results are numeric 0/1. DATE is `YYYY-MM-DD`; DATETIME preserves local
calendar text such as `2026-01-02T03:04:05.123456`; TIMESTAMP preserves microseconds
in UTC with `Z`. Temporal inputs use these same formats. Sessions enforce strict
mode, `NO_BACKSLASH_ESCAPES`, and UTC. Warnings, duplicate columns, invalid dates,
BIT, TIME, spatial and other unsupported result types fail rather than silently
coercing. Project supported fields when a table also contains unsupported types.

Defaults are 10 seconds per operation, 1,000 rows and 1 MiB selected result data.
Connections, query/cancellation and drain are bounded; owned resources close before
return. SQL Server streams with TEXTSIZE and refuses truncation/completeness ceilings.
PostgreSQL row events avoid collecting unselected sets, but native cell decoding
precedes the byte ceiling, so it is not a universal pre-decoding memory bound.
Cancellation drain has a separate finite window.

MySQL bounds streamed rows/bytes after native decoding, with the same per-cell
memory limitation. Each operation owns one connection and transaction. Cancellation
destroys the local socket; server completion or rollback may lag that close.
Connection establishment and lock waits are also bounded by the operation deadline.

Returned rows and affected counts differ. One unambiguous DML count supports min/max;
missing/multiple counts, including trigger counts, are indeterminate rather than summed.
PostgreSQL commits after response completeness/representability checks. Reliable
count/assertion failures remain FAIL and never retry to green.

MySQL DML returns no rows (`rowCount: 0`). UPDATE affectedRows counts matched rows,
including unchanged values, using the native FOUND_ROWS capability. INSERT/DELETE
report their native counts. MySQL commits after result/type/warning validation;
later assertion failures remain failures even when that mutation has committed.

## Supported SQL and recovery

The runtime supports single SELECT/INSERT/UPDATE/DELETE statements, read CTEs,
joins, subqueries, set operations and INSERT SELECT when it can resolve their
scope. Native engines evaluate SQL. There is no universal WHERE requirement.
Supported built-in value, aggregate and window functions run normally. Use
qualified names for database-owned functions. Scope validation rejects unsupported
clauses and object-bearing expressions whose references cannot be resolved.

- SQL Server refuses DDL/admin/EXEC/MERGE, legacy text writes, broker/batch/session
  commands, SELECT INTO, linked/cross-database names, temporary objects and sequence increments.
- PostgreSQL refuses multiple statements, session/admin/DDL, COPY/CALL/DO,
  data-modifying CTEs, UPSERT and Unicode escape syntax. Bound Unicode works.
  SELECT uses a server-enforced read-only transaction. Reserved `pg_*` functions
  are refused except pg_typeof, pg_column_size, pg_backend_pid, pg_sleep,
  pg_sleep_for and pg_sleep_until. Large-object APIs, set_config, query_to_xml
  family and ts_stat/ts_rewrite evaluators are unsupported, including bound/quoted names.
  Use a static sequence name for nextval, currval and setval. Scope resolution
  qualifies it before execution. Computed object names and numeric object IDs
  cannot establish sequence scope.
- MySQL refuses multi-statements, executable/optimizer comments, DDL/admin/session
  commands, CALL/LOAD, REPLACE statements, IGNORE/UPSERT, SELECT INTO, user variables,
  lock/file/admin/session-state functions and guarded restoration. SELECT runs in
  a read-only transaction. INSERT SET and ordinary value functions are supported.

Read-only transactions do not inspect owner-controlled bodies or prevent every
signaling entrypoint. Privileges and scope checks work together; capability overrides
do not add unsupported operations. Safe reads/known unexecuted work may retry within
budget. Sensitive inputs resolve once per invocation. Interrupted transmitted DML
stays uncertain and is not automatically replayed; a lost PostgreSQL or MySQL COMMIT reply can
follow an actual commit. There is no automatic DB reconciliation workflow. A later
read cannot replace a missing response/count assertion. Unresolved effects need review.

Sanitized observation reasons distinguish operation policy failures, scope denials,
unsupported scope or objects, authentication failures and native permission denials.

Only sanitized metadata/checks and selected outputs persist. Raw SQL errors, credentials,
unrestricted rows and before-state are not evidence. Sensitive selectors/overlapping
paths/known values and JSON-encoded values are screened. Protected storage callbacks
return opaque refs; classify domain-sensitive data explicitly.

## Cleanup and guarded restoration

Resources bind an originating identity, ownership and intent. Temporary owned fixtures
need cleanup, borrowed temporary changes may need restore, and persistent/no-obligation
outcomes create neither disposal nor automatic before-image requirements. Cleanup binds
original identity in CLEANUP with `lifecycle: {resourceId}`. Pending/failed obligations
prevent a clean pass while established failures remain. One cleanup budget survives cancellation.

Restoration is opt-in: protected before-state, original identity, and the genuine
post-change version from the originating mutation. Use a direct ordinary-table UPDATE
with terminal identity AND version equality and exactly one affected row. Declare
`restorationGuard: {identityParameter: 'recordId', versionParameter: 'revision'}`.
SQL Server uses server-maintained rowversion; PostgreSQL uses xmin, bound as xid.
Metadata verifies a single-column unique identity. Ordinary version-named columns,
arbitrary initial versions, aliases/joined updates cannot claim that guarantee.
Concurrent changes produce visible conflict. xmin can wrap; use it within short-lived
scenarios, not as a durable global revision token.

MySQL supports identity-bound cleanup for temporary owned fixtures, but rejects
`restorationGuard` and RESTORE execution before credentials or business SQL. An
ordinary version column cannot substitute for SQL Server rowversion or PostgreSQL
xmin. Durable generated MySQL POM services are outside this execution feature.

Run `test:database`, `test:postgresql` and `test:mysql` for contracts/bindings. Native
`probe:database`, `probe:postgresql`, `probe:mysql` and `probe:database-neutrality` need owned disposable
instances and pinned Docker images. SQL Server Developer proofs explicitly accept its
EULA. No private checkout mounts, persistent volumes or backups are used; generated
credentials remain in memory/environment. Docker administrators can inspect live
container environment. Missing prerequisites do not become skipped successes.
After crashes inspect exact owned identities/labels before recovery; preserve unrelated infrastructure.

See [contributing](../contributing.md) and archived
[SQL Server](../archive/milestones/M8-SQLSERVER.md) /
[PostgreSQL](../archive/milestones/M10-POSTGRESQL.md) for full type/guard/proof details.
Database semantic neutrality does not prove all host/workflow behavior.

`probe:mysql` also requires the installed native Chromium browser and proves a real
browser → API → MySQL scenario, exact CRUD/types, policy/privilege rejection, bounded
failure/cancellation, protected outputs, uncertain COMMIT and owned cleanup. Linux
CI runs it from the installed archive; missing prerequisites fail the proof.
