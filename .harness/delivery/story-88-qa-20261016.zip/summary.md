# Browse Products by Category and Brand

## tc\-154 — Ready

Validate main categories \(Women, Men, Kids\) and sub\-categories are displayed in product navigation

Stage: Verification

Reason: Automation is ready\. The test passed verification and review\.

## tc\-156 — Ready

Validate available brands are displayed in the side navigation on the Products page

Stage: Verification

Reason: Automation is ready\. The test passed verification and review\.

## tc\-157 — Ready

Verify selecting a brand displays products belonging to that specific brand

Stage: Verification

Reason: Automation is ready\. The test passed verification and review\.

## tc\-159 — Ready

Verify switching from a brand selection to a category selection updates product list

Stage: Verification

Reason: Automation is ready\. The test passed verification and review\.

## tc\-162 — Ready

Verify navigating to Products page initially displays ALL PRODUCTS catalog

Stage: Verification

Reason: Automation is ready\. The test passed verification and review\.

## tc\-167 — Ready

Validate keyboard navigation for categories and brands in side menu

Stage: Verification

Reason: Automation is ready\. The test passed verification and review\.

