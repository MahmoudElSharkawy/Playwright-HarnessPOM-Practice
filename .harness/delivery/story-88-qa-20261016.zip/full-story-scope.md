# Story 88 automation scope

Six cases are automated and READY: TC154, TC156, TC157, TC159, TC162, TC167. Independent framework review approved candidate revision-aecfd594-b542-4400-bae2-3e53e5d1a2e8. Two independent QA processes each passed all six tests with one worker, zero retries, no skips, and passing native assertions.

Verification receipts: verify-d4ece4c9-729d-48d1-8bf6-4b98158b0422; verify-3e94fed0-61c3-47ba-a86c-1eae19bc0ac3. TypeScript and the changed-file convention check passed (7 files, 116 rule applications, zero new failures or warnings).

The complete story contains twenty cases. The following fourteen remain blocked. These reasons were preserved from prior exploration; this review did not re-execute those cases or change their expectations.


## tc-155

The application labels the Women sub-category "Dress"; no sub-category is named "Dresses", and the expectations name "Dresses" for the page, the list and the title. Treating "Dress" as "Dresses" is a source ruling that has not been made. The Women > Dress page heading reads "Women - Dress Products" (direct probe).

Next action: Owner rules whether "Dress" stands for "Dresses"; then revise the source with generate revise and automate (the journey mirrors TC157/TC159).

## tc-158

The first expectation requires the list to show only "Dresses", but the application labels the sub-category "Dress" (a source ruling is needed, as in TC155). The brand-switch steps are otherwise observable: the Polo brand page replaces the category page.

Next action: Owner rules whether "Dress" stands for "Dresses"; then revise the source and automate.

## tc-160

No sub-category without products exists: per the catalog API run, Women Dress 3, Tops 6, Saree 3; Men Tshirts 6, Jeans 3; Kids Dress 6, Tops & Shirts 7. "Seasonal Wear" does not exist, and no empty-category message was observed. No product or category provisioning operation is published.

Next action: Provision an empty sub-category (or supply the operation) or correct the source.

## tc-161

Every brand has products per the catalog API run (Polo 6, H&M 5, Madame 5, Mast & Harbour 3, Babyhug 4, Allen Solly Junior 3, Kookie Kids 3, Biba 5). "New Arrivals Co." does not exist, and no empty-brand message was observed. No provisioning operation is published.

Next action: Provision a brand with no products or correct the source.

## tc-163

The published API collection has no categories operation (product list, brand list, search and account operations only), so no endpoint was invented. An informal read-only probe of an unpublished /categoriesList returned HTTP 404 (direct probe, not a harness run).

Next action: Owner supplies the categories endpoint and response contract, or confirms none exists.

## tc-164

GET /brandsList (collection operation 03) read through the shared API runtime returned HTTP 200, body code 200 and 34 rows. Each row has "id" (a product id) and "brand" but no "name" field, and brands repeat across rows. The expectation requires brand objects with "id" and "name". "Polo" and "H&M" are present.

Next action: Owner rules whether the source should say "brand" or the API should expose "name"; then automate.

## tc-165

The harness refuses network interception and the application filters by page navigation to /category_products/<id> and /brand_products/<name>, with no filtered-products API to observe. The source labels do not exist either: the sub-category is "Tshirts" not "T-Shirts" and no brand "Roadster" exists (harness runs).

Next action: Provide a supported way to observe the filter request, supply the fixtures, or revise the source.

## tc-166

At 375 x 812 the Category and Brands panels render inline below the header and are always visible; there is no hamburger or side-navigation control, so "when tapped, reveals the categories and brands list" has no matching control (direct probe, not a harness run). The mobile flow was not explored in the harness.

Next action: Owner rules which control the expectation means; then explore the mobile flow with visual evidence.

## tc-168

The case needs the category/brand API mocked to fail. The harness refuses routing, the application renders categories and brands on the server with no such API, and no controlled-failure environment is configured.

Next action: Provide a controlled failure mechanism or revise the source.

## tc-169

The source is inconsistent (steps use "red dress" and Polo; the data names "dress" and Madame) and the first expectation needs the same "Dresses" ruling as TC155. Search behavior for the chosen term was not explored.

Next action: Correct the source, rule on "Dresses", then explore the search and filter-reset journey.

## tc-170

The case needs a category with an exceptionally long name injected into the navigation. The application is public and read-only here; no fixture or provisioning mechanism exists.

Next action: Provide a way to create the long-named category or revise the source.

## tc-171

Breadcrumbs exist on category and brand pages but read "Products Women > Dress" and "Products Polo" (direct probe, not a harness run), not "Home > Women > Dresses" and "Home > Polo": the root crumb is "Products", the label is "Dress", and the Products page has none. Not executed in the harness.

Next action: Owner rules on the expected breadcrumb text (source correction or application change); then explore and automate.

## tc-172

No "Clear All Filters" control or equivalent appears in any rendered page observed through the harness (Women has Dress, Tops and Saree; Men has Tshirts and Jeans; Kids has Dress and Tops & Shirts). Selecting a brand or sub-category navigates to a separate page that replaces the previous selection, so there is no combined filter state to clear.

Next action: Owner rules whether the control is expected (application change) or corrects the source.

## tc-173

Sub-category "Shoes" (ID shoes123) and brand "Nike" (ID nike456) do not exist. The application routes by path (/category_products/<number>, /brand_products/<name>), not by "?category=" or "?brand=" query parameters.

Next action: Supply the fixtures and correct the URL expectation in the source.

## Limits

The remaining nonblocking review notes concern duplicated Category-heading ownership and the keyboard report title saying all 2 brands when it samples two of eight links. Existing unrelated suites were not rerun. No ADO bugs or test outcomes were published.
