# Browse Products by Category and Brand

## tc\-154 — Not generated

Validate main categories \(Women, Men, Kids\) and sub\-categories are displayed in product navigation

Stage: Exploration

Reason: No automated test has been recorded for this case\.

Next action: Check the case requirements and application behavior before creating the test\.

## tc\-155 — Blocked

Verify selecting a sub\-category displays products for that specific category

Stage: Exploration

Reason: The application labels the Women sub\-category "Dress"; no sub\-category is named "Dresses", and the expectations name "Dresses" for the page, the list and the title\. Treating "Dress" as "Dresses" is a source ruling that has not been made\. The Women \> Dress page heading reads "Women \- Dress Products" \(direct probe\)\.

Next action: Owner rules whether "Dress" stands for "Dresses"; then revise the source with generate revise and automate \(the journey mirrors TC157/TC159\)\.

## tc\-156 — Not generated

Validate available brands are displayed in the side navigation on the Products page

Stage: Exploration

Reason: No automated test has been recorded for this case\.

Next action: Check the case requirements and application behavior before creating the test\.

## tc\-157 — Not generated

Verify selecting a brand displays products belonging to that specific brand

Stage: Exploration

Reason: No automated test has been recorded for this case\.

Next action: Check the case requirements and application behavior before creating the test\.

## tc\-158 — Blocked

Verify switching from a category selection to a brand selection updates product list

Stage: Exploration

Reason: The first expectation requires the list to show only "Dresses", but the application labels the sub\-category "Dress" \(a source ruling is needed, as in TC155\)\. The brand\-switch steps are otherwise observable: the Polo brand page replaces the category page\.

Next action: Owner rules whether "Dress" stands for "Dresses"; then revise the source and automate\.

## tc\-159 — Not generated

Verify switching from a brand selection to a category selection updates product list

Stage: Exploration

Reason: No automated test has been recorded for this case\.

Next action: Check the case requirements and application behavior before creating the test\.

## tc\-160 — Blocked

Validate empty product list when selected category has no products

Stage: Exploration

Reason: No sub\-category without products exists: per the catalog API run, Women Dress 3, Tops 6, Saree 3; Men Tshirts 6, Jeans 3; Kids Dress 6, Tops & Shirts 7\. "Seasonal Wear" does not exist, and no empty\-category message was observed\. No product or category provisioning operation is published\.

Next action: Provision an empty sub\-category \(or supply the operation\) or correct the source\.

## tc\-161 — Blocked

Validate empty product list when selected brand has no products

Stage: Exploration

Reason: Every brand has products per the catalog API run \(Polo 6, H&M 5, Madame 5, Mast & Harbour 3, Babyhug 4, Allen Solly Junior 3, Kookie Kids 3, Biba 5\)\. "New Arrivals Co\." does not exist, and no empty\-brand message was observed\. No provisioning operation is published\.

Next action: Provision a brand with no products or correct the source\.

## tc\-162 — Not generated

Verify navigating to Products page initially displays ALL PRODUCTS catalog

Stage: Exploration

Reason: No automated test has been recorded for this case\.

Next action: Check the case requirements and application behavior before creating the test\.

## tc\-163 — Blocked

Validate API response for categories and sub\-categories contains expected structure

Stage: Exploration

Reason: The published API collection has no categories operation \(product list, brand list, search and account operations only\), so no endpoint was invented\. An informal read\-only probe of an unpublished /categoriesList returned HTTP 404 \(direct probe, not a harness run\)\.

Next action: Owner supplies the categories endpoint and response contract, or confirms none exists\.

## tc\-164 — Blocked

Validate API response for brands contains expected structure and values

Stage: Exploration

Reason: GET /brandsList \(collection operation 03\) read through the shared API runtime returned HTTP 200, body code 200 and 34 rows\. Each row has "id" \(a product id\) and "brand" but no "name" field, and brands repeat across rows\. The expectation requires brand objects with "id" and "name"\. "Polo" and "H&M" are present\.

Next action: Owner rules whether the source should say "brand" or the API should expose "name"; then automate\.

## tc\-165 — Blocked

Verify category/brand filters are applied consistently between UI and API requests

Stage: Exploration

Reason: The harness refuses network interception and the application filters by page navigation to /category\_products/\<id\> and /brand\_products/\<name\>, with no filtered\-products API to observe\. The source labels do not exist either: the sub\-category is "Tshirts" not "T\-Shirts" and no brand "Roadster" exists \(harness runs\)\.

Next action: Provide a supported way to observe the filter request, supply the fixtures, or revise the source\.

## tc\-166 — Blocked

Validate side navigation visibility and usability on mobile devices

Stage: Exploration

Reason: At 375 x 812 the Category and Brands panels render inline below the header and are always visible; there is no hamburger or side\-navigation control, so "when tapped, reveals the categories and brands list" has no matching control \(direct probe, not a harness run\)\. The mobile flow was not explored in the harness\.

Next action: Owner rules which control the expectation means; then explore the mobile flow with visual evidence\.

## tc\-167 — Not generated

Validate keyboard navigation for categories and brands in side menu

Stage: Exploration

Reason: No automated test has been recorded for this case\.

Next action: Check the case requirements and application behavior before creating the test\.

## tc\-168 — Blocked

Validate category/brand navigation when no product data is available \(API failure\)

Stage: Exploration

Reason: The case needs the category/brand API mocked to fail\. The harness refuses routing, the application renders categories and brands on the server with no such API, and no controlled\-failure environment is configured\.

Next action: Provide a controlled failure mechanism or revise the source\.

## tc\-169 — Blocked

Validate consistent filter behavior after using product search

Stage: Exploration

Reason: The source is inconsistent \(steps use "red dress" and Polo; the data names "dress" and Madame\) and the first expectation needs the same "Dresses" ruling as TC155\. Search behavior for the chosen term was not explored\.

Next action: Correct the source, rule on "Dresses", then explore the search and filter\-reset journey\.

## tc\-170 — Blocked

Validate long category names wrap or truncate gracefully in side navigation

Stage: Exploration

Reason: The case needs a category with an exceptionally long name injected into the navigation\. The application is public and read\-only here; no fixture or provisioning mechanism exists\.

Next action: Provide a way to create the long\-named category or revise the source\.

## tc\-171 — Blocked

Validate breadcrumbs update correctly with category and brand selections

Stage: Exploration

Reason: Breadcrumbs exist on category and brand pages but read "Products Women \> Dress" and "Products Polo" \(direct probe, not a harness run\), not "Home \> Women \> Dresses" and "Home \> Polo": the root crumb is "Products", the label is "Dress", and the Products page has none\. Not executed in the harness\.

Next action: Owner rules on the expected breadcrumb text \(source correction or application change\); then explore and automate\.

## tc\-172 — Blocked

Verify clear all filters functionality resets category and brand selections

Stage: Exploration

Reason: No "Clear All Filters" control or equivalent appears in any rendered page observed through the harness \(Women has Dress, Tops and Saree; Men has Tshirts and Jeans; Kids has Dress and Tops & Shirts\)\. Selecting a brand or sub\-category navigates to a separate page that replaces the previous selection, so there is no combined filter state to clear\.

Next action: Owner rules whether the control is expected \(application change\) or corrects the source\.

## tc\-173 — Blocked

Verify URL parameters update correctly for category and brand filters

Stage: Exploration

Reason: Sub\-category "Shoes" \(ID shoes123\) and brand "Nike" \(ID nike456\) do not exist\. The application routes by path \(/category\_products/\<number\>, /brand\_products/\<name\>\), not by "?category=" or "?brand=" query parameters\.

Next action: Supply the fixtures and correct the URL expectation in the source\.

