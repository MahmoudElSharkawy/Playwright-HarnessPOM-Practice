# Browse Products by Category and Brand

## Case 154: Validate main categories \(Women, Men, Kids\) and sub\-categories are displayed in product navigation

Status: Passed

## Case 155: Verify selecting a sub\-category displays products for that specific category

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The source requires Dresses, while the current navigation says Dress and its page heading says Women \- Dress Products\. No accepted source correction is available\.

Next action: Obtain an owner ruling on Dress versus the required Dresses label, then rerun the unchanged case or an accepted source revision\.

## Case 156: Validate available brands are displayed in the side navigation on the Products page

Status: Passed

## Case 157: Verify selecting a brand displays products belonging to that specific brand

Status: Passed

## Case 158: Verify switching from a category selection to a brand selection updates product list

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The category checkpoint still requires Dresses, while the available sub\-category is Dress\. The original checkpoint needs an application change or an explicitly accepted source correction\.

Next action: Resolve the Dresses checkpoint before running the category\-to\-brand journey\.

## Case 159: Verify switching from a brand selection to a category selection updates product list

Status: Passed

## Case 160: Validate empty product list when selected category has no products

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The current catalog and navigation expose seven sub\-categories, all with products\. Seasonal Wear and an empty sub\-category are unavailable; the supplied API collection has no category/product provisioning operation\.

Next action: Provide the Seasonal Wear category with zero products and an approved way to maintain that fixture\.

## Case 161: Validate empty product list when selected brand has no products

Status: Blocked

Reason: Reassessed on 2026\-10\-17: All eight current brands have products\. New Arrivals Co\. and an empty\-brand fixture are unavailable, and no brand/product provisioning operation is supplied\.

Next action: Provide the New Arrivals Co\. brand with zero products and an approved way to maintain that fixture\.

## Case 162: Verify navigating to Products page initially displays ALL PRODUCTS catalog

Status: Passed

## Case 163: Validate API response for categories and sub\-categories contains expected structure

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The team API collection has no categories endpoint or response contract\. A supported categories contract is required before the specified API checks can be derived\.

Next action: Supply the supported categories endpoint and its response contract\.

## Case 164: Validate API response for brands contains expected structure and values

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The current brand\-list response has id and brand fields, with repeated brands across 34 product\-associated rows\. The source requires id and name; no accepted schema correction is available\.

Next action: Resolve the source id/name contract versus the observed id/brand response before completing the schema case\.

## Case 165: Verify category/brand filters are applied consistently between UI and API requests

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The current navigation uses Tshirts, while the source names T\-Shirts; Roadster is also unavailable\. Filtering navigates to category/brand pages, and the required filtered\-products API contract for interception has not been supplied\.

Next action: Provide the T\-Shirts and Roadster fixtures and a supported contract for observing the actual filtered network requests and responses\.

## Case 166: Validate side navigation visibility and usability on mobile devices

Status: Blocked

Reason: Reassessed on 2026\-10\-17: Fresh inspection at 375 by 812 shows the product navigation inline below search\. The tap\-to\-reveal side\-navigation control required by the source is absent, so its reveal journey cannot be performed\.

Next action: Identify or implement the required mobile navigation reveal control, or accept a source correction describing the inline layout\.

## Case 167: Validate keyboard navigation for categories and brands in side menu

Status: Passed

## Case 168: Validate category/brand navigation when no product data is available \(API failure\)

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The source requires a controlled empty/error category or brand API response\. The selected environment has populated server\-rendered navigation, with no supplied categories API or controlled\-failure contract matching this scenario\.

Next action: Supply a controlled failure mechanism for the actual navigation data source\.

## Case 169: Validate consistent filter behavior after using product search

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The unchanged source disagrees between setup values dress/Madame and step values red dress/Polo, and still requires Dresses while navigation says Dress\. These source decisions remain unresolved\.

Next action: Resolve the required Dresses label and the setup/action input differences, then run the search and filter\-reset journey\.

## Case 170: Validate long category names wrap or truncate gracefully in side navigation

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The exceptionally long category fixture is unavailable, and the supplied collection offers no catalog\-provisioning operation\. A real usable long\-name category is required for the responsive and interaction journey\.

Next action: Provide a usable long\-name category and an approved provisioning or faithful injection mechanism\.

## Case 171: Validate breadcrumbs update correctly with category and brand selections

Status: Blocked

Reason: Reassessed on 2026\-10\-17: Current breadcrumbs read Products Women \> Dress and Products Polo\. The source requires Home \> Women \> Dresses and Home \> Polo, followed by Home navigation\. No accepted correction or matching application behavior is available\.

Next action: Resolve the expected Home breadcrumb journey versus the current Products breadcrumb behavior\.

## Case 172: Verify clear all filters functionality resets category and brand selections

Status: Passed

## Case 173: Verify URL parameters update correctly for category and brand filters

Status: Blocked

Reason: Reassessed on 2026\-10\-17: The Shoes/shoes123 and Nike/nike456 fixtures are unavailable\. The source permits URL parameters like its examples or similar; path routing alone is not classified as a mismatch\. Actual filter identity and copied\-link persistence still require the specified usable fixtures\.

Next action: Provide Shoes/shoes123 and Nike/nike456 fixtures, then verify actual filter identity and copied\-link persistence\.

